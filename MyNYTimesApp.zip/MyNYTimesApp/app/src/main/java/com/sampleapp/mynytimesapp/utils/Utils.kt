package com.sampleapp.mynytimesapp.utils

import android.content.Context
import android.net.ConnectivityManager

class Utils {

    companion object{
        /**
         * Used to check the internet connectio available or not.
         */
        fun checkInternetConnection(ctx: Context): Boolean {
            val conMgr = ctx
                .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val info = conMgr.activeNetworkInfo
            return if (info != null && info.isConnected) {
                true
            } else {
                false
            }
        }
    }
}