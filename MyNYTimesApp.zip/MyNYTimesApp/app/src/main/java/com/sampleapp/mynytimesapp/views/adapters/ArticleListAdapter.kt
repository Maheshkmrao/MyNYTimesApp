package com.sampleapp.mynytimesapp.views.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.sampleapp.mynytimesapp.R
import com.sampleapp.mynytimesapp.model.ArticleBean
import com.sampleapp.mynytimesapp.utils.CircleTransform
import com.squareup.picasso.Picasso

class ArticleListAdapter(private val list: List<ArticleBean>, val clickListener: (Int)-> Unit)
    :RecyclerView.Adapter<ArticleViewHolder>(){

    var context: Context? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArticleViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val itemView = inflater.inflate(R.layout.article_list_item, parent, false)
        context = parent.context
        return ArticleViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ArticleViewHolder, position: Int) {
        val article: ArticleBean = list[position]
        holder.bind(article, context!!)
        (holder as ArticleViewHolder).clickableView.setOnClickListener {
            clickListener(position)
        }
    }

    override fun getItemCount(): Int = list.size
}

class ArticleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private var mTitleView: TextView? = null
        private var mAuthorView: TextView? = null
        private var mTimestampView: TextView? = null
        private var mThumbnailView: ImageView? = null

        val clickableView = itemView.rootView

        init {
            mTitleView = itemView.findViewById(R.id.subject)
            mAuthorView = itemView.findViewById(R.id.author)
            mTimestampView = itemView.findViewById(R.id.timestamp)
            mThumbnailView = itemView.findViewById(R.id.thumbnail)
        }

        fun bind(article: ArticleBean, context: Context) {
            mTitleView?.text = article.title
            mAuthorView?.text = article.byline
            mTimestampView?.text = article.published_date

//            Toast.makeText(context, "Recycler: " + article?.title, Toast.LENGTH_LONG ).show()
            var thumbImage = article.media?.get(0)?.mediametadata?.get(0)?.url
            thumbImage?.replace("\\/", "/", true)

            val transf: CircleTransform = CircleTransform()
            Picasso.get().load(thumbImage).transform(transf).placeholder(R.drawable.ic_launcher_background).fit().into(mThumbnailView)
        }

}