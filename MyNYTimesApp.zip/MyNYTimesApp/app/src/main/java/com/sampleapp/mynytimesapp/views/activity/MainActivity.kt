package com.sampleapp.mynytimesapp.views.activity

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.sampleapp.mynytimesapp.R
import com.sampleapp.mynytimesapp.common.Constants
import com.sampleapp.mynytimesapp.model.ArticleBean
import com.sampleapp.mynytimesapp.model.ArticleResponse
import com.sampleapp.mynytimesapp.network.ApiInterface
import com.sampleapp.mynytimesapp.utils.Utils
import com.sampleapp.mynytimesapp.views.adapters.ArticleListAdapter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    var articleList: List<ArticleBean>? = null
    var mActivity: Activity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)

        mActivity = this
        recycler_view.apply {
            layoutManager = LinearLayoutManager(mActivity) }
        val divider = DividerItemDecoration(recycler_view.getContext(),
            DividerItemDecoration.VERTICAL)
        divider.setDrawable(
            ContextCompat.getDrawable(baseContext, R.drawable.line_divider)!!)
        recycler_view.addItemDecoration(divider)

        if(Utils.checkInternetConnection(applicationContext))
            getArticles()
        else {
            val snackbar = Snackbar
                .make(constraint_layout, getString(R.string.no_internet), Snackbar.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        shimmer_view_container.startShimmerAnimation()
    }

    override fun onPause() {
        super.onPause()
        shimmer_view_container.stopShimmerAnimation()
    }

    fun getArticles(){
        val apiService = ApiInterface.create()
        val call =apiService.getAllArticles(Constants.SECTION, Constants.PERIOD, Constants.NY_TIMES_API_KEY)

        call.enqueue(object: Callback<ArticleResponse>{
            override fun onResponse(call: Call<ArticleResponse>, response: Response<ArticleResponse>) {
                if (response != null) {
                    articleList =response.body().results!!
                    recycler_view.adapter = ArticleListAdapter(articleList!!, clickListener = {
                        appClickListener(it)
                    })

                    shimmer_view_container.stopShimmerAnimation()
                    shimmer_view_container.visibility = View.GONE
                }
            }

            override fun onFailure(call: Call<ArticleResponse>, t: Throwable) {
                val snackbar = Snackbar
                    .make(constraint_layout, getString(R.string.error_response), Snackbar.LENGTH_LONG).show()
            }
        })
    }

    fun appClickListener(position: Int) {
        val intent = Intent(this, ArticleDetailsActivity::class.java)
        intent.putExtra(Constants.KEY_ARTICLE_BEAN, articleList!!.get(position))
        startActivity(intent)
    }

}
