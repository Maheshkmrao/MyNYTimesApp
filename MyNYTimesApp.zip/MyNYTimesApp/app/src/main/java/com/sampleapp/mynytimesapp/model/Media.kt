package com.sampleapp.mynytimesapp.model

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable

class Media() : Serializable{


    @SerializedName("type")
    @Expose
    var type : String? = null
    @SerializedName("subtype")
    @Expose
    var subtype : String? = null
    @SerializedName("caption")
    @Expose
    var caption : String? = null
    @SerializedName("copyright")
    @Expose
    var copyright : String? = null
    @SerializedName("approved_for_syndication")
    @Expose
    var approved_for_syndication : Int? = null
    @SerializedName("media-metadata")
    @Expose
    var mediametadata : ArrayList<MediaMetadata>? = null

   /* constructor(parcel: Parcel) : this() {
        type = parcel.readString()
        subtype = parcel.readString()
        caption = parcel.readString()
        copyright = parcel.readString()
        approved_for_syndication = parcel.readInt()
        mediametadata = arrayListOf<MediaMetadata>().apply {
            parcel.readArrayList(MediaMetadata::class.java.classLoader)
        }
//        media = parcel.readList(media!!, Media::class.java.classLoader)
    }

    override fun writeToParcel(parcel: Parcel, p1: Int) {
        parcel.writeString(type)
        parcel.writeString(subtype)
        parcel.writeString(caption)
        parcel.writeString(copyright)
        parcel.writeInt(approved_for_syndication!!)
        parcel.writeList(mediametadata!!)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Media> {
        override fun createFromParcel(parcel: Parcel): Media {
            return Media(parcel)
        }

        override fun newArray(size: Int): Array<Media?> {
            return arrayOfNulls(size)
        }
    }*/
}