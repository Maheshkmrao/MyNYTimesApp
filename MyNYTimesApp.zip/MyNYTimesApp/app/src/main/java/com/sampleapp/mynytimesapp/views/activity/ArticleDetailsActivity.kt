package com.sampleapp.mynytimesapp.views.activity

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity;
import com.sampleapp.mynytimesapp.R
import com.sampleapp.mynytimesapp.common.Constants
import com.sampleapp.mynytimesapp.model.ArticleBean
import com.squareup.picasso.Picasso

import kotlinx.android.synthetic.main.activity_article_details.*
import kotlinx.android.synthetic.main.activity_article_details.toolbar
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.content_article_details.*

class ArticleDetailsActivity : AppCompatActivity() {

    var article: ArticleBean? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_article_details)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        article = intent.getSerializableExtra(Constants.KEY_ARTICLE_BEAN) as? ArticleBean
        setDetailsInControls()
    }

    fun setDetailsInControls(){
        title_textview.setText(article?.title)
        description.setText(article?.abstract)
        author.setText(article?.byline)
        timestamp.setText(article?.published_date)
        var thumbImage = article?.media?.get(0)?.mediametadata?.get(4)?.url
        thumbImage?.replace("\\/", "/", true)
        Picasso.get().load(thumbImage).placeholder(R.drawable.ic_launcher_background).into(imageView)

    }
}
