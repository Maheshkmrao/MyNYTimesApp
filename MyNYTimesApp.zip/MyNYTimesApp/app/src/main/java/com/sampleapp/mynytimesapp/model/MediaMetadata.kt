package com.sampleapp.mynytimesapp.model

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable

class MediaMetadata() :Serializable{

    @SerializedName("url")
    @Expose
    var url : String? = null
    @SerializedName("format")
    @Expose
    var format : String? = null
    @SerializedName("height")
    @Expose
    var height : Int? = null
    @SerializedName("width")
    @Expose
    var width : Int? = null

    /*constructor(parcel: Parcel) : this() {
        url = parcel.readString()
        format = parcel.readString()
        height = parcel.readInt()
        width = parcel.readInt()

    }

    override fun writeToParcel(parcel: Parcel, p1: Int) {
        parcel.writeString(url)
        parcel.writeString(format)
        parcel.writeInt(height!!)
        parcel.writeInt(width!!)

    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<MediaMetadata> {
        override fun createFromParcel(parcel: Parcel): MediaMetadata {
            return MediaMetadata(parcel)
        }

        override fun newArray(size: Int): Array<MediaMetadata?> {
            return arrayOfNulls(size)
        }
    }*/
}