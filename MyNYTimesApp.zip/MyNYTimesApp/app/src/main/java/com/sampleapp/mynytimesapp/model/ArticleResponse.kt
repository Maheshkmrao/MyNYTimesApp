package com.sampleapp.mynytimesapp.model

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

class ArticleResponse {

    @SerializedName("status")
    val status : String? = null
    @SerializedName("copyright")
    val copyright : String? = null
    @SerializedName("num_results")
    val num_results : Int? = null
    @SerializedName("results")
    val results : List<ArticleBean>? = null

}