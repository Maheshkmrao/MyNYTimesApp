package com.sampleapp.mynytimesapp.model

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.io.Serializable

class ArticleBean() : Serializable {
    @SerializedName("url")
    @Expose
    var url : String? = null
    @SerializedName("adx_adx_keywordswords")
    @Expose
    var adx_adx_keywordswords : String? = null
    @SerializedName("column")
    @Expose
    var column : String? = null
    @SerializedName("section")
    @Expose
    var section : String? = null
    @SerializedName("byline")
    @Expose
    var byline : String? = null
    @SerializedName("type")
    @Expose
    var type : String? = null
    @SerializedName("title")
    @Expose
    var title : String? = null
    @SerializedName("abstract")
    @Expose
    var abstract : String? = null
    @SerializedName("published_date")
    @Expose
    var published_date : String? = null
    @SerializedName("source")
    @Expose
    var source : String? = null
    @SerializedName("id")
    @Expose
    var id : Float? = null
    @SerializedName("asset_id")
    @Expose
    var asset_id : Float? = null
    @SerializedName("views")
    @Expose
    var views : Int? = null
    @SerializedName("media")
    @Expose
    var media : ArrayList<Media>? = null

//    constructor(parcel: Parcel) : this() {
//        url = parcel.readString()
//        adx_adx_keywordswords = parcel.readString()
//        column = parcel.readString()
//        section = parcel.readString()
//        byline = parcel.readString()
//        type = parcel.readString()
//        title = parcel.readString()
//        abstract = parcel.readString()
//        published_date = parcel.readString()
//        source = parcel.readString()
//        id = parcel.readFloat()
//        asset_id = parcel.readFloat()
//        views = parcel.readInt()
//        media = parcel.readList(this, Media::class.java.classLoader)
//    }
//
//    override fun writeToParcel(parcel: Parcel, flags: Int) {
//        parcel.writeString(url)
//        parcel.writeString(adx_adx_keywordswords)
//        parcel.writeString(column)
//        parcel.writeString(section)
//        parcel.writeString(byline)
//        parcel.writeString(type)
//        parcel.writeString(title)
//        parcel.writeString(abstract)
//        parcel.writeString(published_date)
//        parcel.writeString(source)
//        parcel.writeFloat(id!!)
//        parcel.writeFloat(asset_id!!)
//        parcel.writeInt(views!!)
//        parcel.writeList(media!!)
////        parcel.writeTypedList(media!!)
////        parcel.writeValue(media!!)
//    }
//
//    override fun describeContents(): Int {
//        return 0
//    }
//
//    companion object CREATOR : Parcelable.Creator<ArticleBean> {
//        override fun createFromParcel(parcel: Parcel): ArticleBean {
//            return ArticleBean(parcel)
//        }
//
//        override fun newArray(size: Int): Array<ArticleBean?> {
//            return arrayOfNulls(size)
//        }
//    }
}