package com.sampleapp.mynytimesapp.network

import com.sampleapp.mynytimesapp.common.Constants
import com.sampleapp.mynytimesapp.model.ArticleResponse
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.converter.scalars.ScalarsConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.net.InetSocketAddress

public interface ApiInterface {

    @GET("{section}/{period}.json?")
    abstract fun getAllArticles(@Path("section") section: String, @Path("period") period: Int,
                                @Query("api-key") key: String): Call<ArticleResponse>

    companion object Factory{

        fun create(): ApiInterface{
            val retrofit = Retrofit.Builder()
                            .baseUrl(Constants.BASE_URL_NY_TIMES)
                            .addConverterFactory(GsonConverterFactory.create())
                            .build()

            return retrofit.create(ApiInterface::class.java)
        }
    }
}