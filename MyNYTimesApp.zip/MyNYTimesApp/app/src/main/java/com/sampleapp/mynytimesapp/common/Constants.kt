package com.sampleapp.mynytimesapp.common

class Constants {

    companion object{
        val BASE_URL_NY_TIMES = "http://api.nytimes.com/svc/mostpopular/v2/mostviewed/"
        val SECTION = "all-sections"
        val PERIOD = 1
        val NY_TIMES_API_KEY = "nrOwvKAdPrBYPLRNN5oznma9cpiHNtfa"
        val KEY_ARTICLE_BEAN = "ARTICLE_BEAN"
    }

}